<?php

namespace App\Http\Controllers\Front\pages;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class ClinicAndOfficeController extends Controller
{
    //
}
